"""
Internal Gemini provider test — NOT a Telegram command.

Run manually to verify the Gemini integration end-to-end:

    python -m tests.test_gemini_provider

Tests performed (all internal, no bot interaction):
  1. is_configured()          — API key present in environment
  2. generate_response()      — live call with a simple anime prompt
  3. health_check()           — lightweight availability probe
  4. router.route()           — full pipeline: AIRouter → GeminiProvider
  5. context injection        — structured data block reaches Gemini
  6. error handling           — graceful failure on bad key

Results are printed to stdout. Exit code 0 = all passed.
"""
from __future__ import annotations

import asyncio
import os
import sys


# ── Helpers ───────────────────────────────────────────────────────────────────

PASS = "✅"
FAIL = "❌"
SKIP = "⏭"

_results: list[tuple[str, str, str]] = []   # (status, name, detail)


def _record(status: str, name: str, detail: str = "") -> None:
    _results.append((status, name, detail))
    icon = {"✅": PASS, "❌": FAIL, "⏭": SKIP}.get(status, status)
    line = f"  {icon}  {name}"
    if detail:
        line += f"\n       {detail}"
    print(line)


# ── Individual tests ──────────────────────────────────────────────────────────

def test_is_configured() -> None:
    """API key must be present before any network test runs."""
    from ai.providers.gemini import GeminiProvider
    provider = GeminiProvider()
    if provider.is_configured():
        _record(PASS, "is_configured()", "GEMINI_API_KEY found in environment")
    else:
        _record(FAIL, "is_configured()", "GEMINI_API_KEY missing — set it in Replit Secrets")


async def test_generate_response() -> None:
    """Send a simple anime question and verify a non-empty text reply."""
    from ai.providers.gemini import GeminiProvider
    provider = GeminiProvider()

    if not provider.is_configured():
        _record(SKIP, "generate_response()", "skipped — key not set")
        return

    response = await provider.generate_response(
        prompt="In one sentence, what is Attack on Titan about?",
    )

    if response.success and response.text:
        preview = response.text[:120].replace("\n", " ")
        _record(PASS, "generate_response()", f"provider={response.provider} | {preview}…")
    else:
        _record(FAIL, "generate_response()", f"error={response.error}")


async def test_health_check() -> None:
    """Lightweight probe — should return True when key is valid."""
    from ai.providers.gemini import GeminiProvider
    provider = GeminiProvider()

    if not provider.is_configured():
        _record(SKIP, "health_check()", "skipped — key not set")
        return

    ok = await provider.health_check()
    if ok:
        _record(PASS, "health_check()", "provider is reachable")
    else:
        _record(FAIL, "health_check()", "probe returned False — check API key / quota")


async def test_router_route() -> None:
    """Full pipeline: AIRouter selects Gemini and returns a ProviderResponse."""
    from ai.router import AIRouter
    router = AIRouter()

    available = router.available_providers()
    if "gemini" not in available:
        _record(SKIP, "router.route()", f"gemini not in available_providers={available}")
        return

    response = await router.route(
        prompt="Recommend one short anime series for a beginner.",
        provider="gemini",
    )

    if response.success:
        preview = response.text[:120].replace("\n", " ")
        _record(
            PASS, "router.route()",
            f"provider={response.provider} latency={response.latency_ms:.0f}ms | {preview}…",
        )
    else:
        _record(FAIL, "router.route()", f"error={response.error}")


async def test_context_injection() -> None:
    """Verify structured context is accepted without crashing."""
    from ai.providers.gemini import GeminiProvider
    provider = GeminiProvider()

    if not provider.is_configured():
        _record(SKIP, "context injection", "skipped — key not set")
        return

    anime_context = {
        "title": "Fullmetal Alchemist: Brotherhood",
        "score": 9.1,
        "genres": ["Action", "Adventure", "Drama"],
        "status": "Finished",
    }

    response = await provider.generate_response(
        prompt="Is this anime good for a first-time viewer?",
        context=anime_context,
    )

    if response.success and response.text:
        _record(PASS, "context injection", "context dict accepted; response received")
    else:
        _record(FAIL, "context injection", f"error={response.error}")


async def test_error_handling_bad_key() -> None:
    """Temporarily override the key to verify graceful error handling."""
    from ai.providers.gemini import GeminiProvider

    original_key = os.environ.get("GEMINI_API_KEY", "")
    os.environ["GEMINI_API_KEY"] = "INVALID_KEY_FOR_TEST"

    provider = GeminiProvider()   # fresh instance — no cached client
    response = await provider.generate_response(prompt="hello")

    # Restore
    if original_key:
        os.environ["GEMINI_API_KEY"] = original_key
    else:
        del os.environ["GEMINI_API_KEY"]

    if not response.success and response.error:
        _record(PASS, "error handling (bad key)", f"graceful failure: {response.error[:80]}")
    else:
        _record(FAIL, "error handling (bad key)", "expected failure but got success=True")


async def test_empty_prompt_guard() -> None:
    """Empty prompt should not crash — provider returns something or fails cleanly."""
    from ai.providers.gemini import GeminiProvider
    provider = GeminiProvider()

    if not provider.is_configured():
        _record(SKIP, "empty prompt guard", "skipped — key not set")
        return

    try:
        response = await provider.generate_response(prompt="")
        # Either a response or a clean error — either is acceptable
        _record(PASS, "empty prompt guard", f"success={response.success} no exception raised")
    except Exception as exc:
        _record(FAIL, "empty prompt guard", f"raised {type(exc).__name__}: {exc}")


# ── Runner ────────────────────────────────────────────────────────────────────

async def run_all() -> int:
    print("\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print("  Ani Zeo — Gemini Provider Integration Tests")
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n")

    test_is_configured()
    await test_generate_response()
    await test_health_check()
    await test_router_route()
    await test_context_injection()
    await test_error_handling_bad_key()
    await test_empty_prompt_guard()

    passed = sum(1 for s, _, _ in _results if s == PASS)
    failed = sum(1 for s, _, _ in _results if s == FAIL)
    skipped = sum(1 for s, _, _ in _results if s == SKIP)

    print(f"\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print(f"  Results: {passed} passed · {failed} failed · {skipped} skipped")
    print(f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n")

    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(asyncio.run(run_all()))
